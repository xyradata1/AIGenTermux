# AIGenTermux

AI Generator for Termux using OpenAI.

## Installation
```bash
pip install aigentermux
```

## Usage
- `aigen`: Run the AI assistant
- `aigen-admin`: Configure API keys and settings
