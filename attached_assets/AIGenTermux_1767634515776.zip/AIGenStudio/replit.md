# AIGenTermux

## Overview

AIGenTermux is a command-line AI assistant designed for Termux (Android terminal emulator) that interfaces with OpenAI's API. The application provides two entry points: `aigen` for running the interactive AI chat assistant, and `aigen-admin` for configuring API keys and model settings. It stores user configuration in a JSON file in the user's home directory.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Application Structure
The project follows a simple Python package structure with clear separation of concerns:

- **main.py** - Core chat loop that handles user interaction with the OpenAI API
- **admin.py** - Configuration management interface for setting API keys and model preferences
- **config.py** - Centralized configuration handling with JSON file persistence

### Design Decisions

**Configuration Storage**
- Uses JSON file storage at `~/.aigentermux/config.json`
- Chosen for simplicity and portability on Termux/mobile environments
- No database required - lightweight file-based approach suits the single-user CLI context

**User Interface**
- Rich library provides formatted console output with colors and markdown rendering
- Interactive prompts for configuration and chat input
- Markdown rendering for AI responses improves readability of code blocks and formatted text

**API Integration Pattern**
- Stateless chat design - each prompt is sent independently without conversation history
- Model selection is user-configurable (defaults to gpt-3.5-turbo)
- Error handling wraps API calls with user-friendly error messages

## External Dependencies

### Third-Party Libraries
- **openai** - Official OpenAI Python client for API communication
- **rich** - Terminal formatting, markdown rendering, and styled prompts

### External Services
- **OpenAI API** - Requires user-provided API key configured via `aigen-admin`